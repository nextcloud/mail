$(document).ready(function() {
	$('#redirectLink').get(0).click();
});
